package com.varma.discipline

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 26 WEEKS OF DISCIPLINE - live wallpaper.
 * Everything is computed from the system clock, so it updates itself
 * every second (countdown) and every day/week (progress) with no input.
 */
class DisciplineWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = DisciplineEngine()

    inner class DisciplineEngine : Engine() {

        // ---- Challenge configuration ----
        private val startDate: LocalDate = LocalDate.of(2026, 11, 16)
        private val totalWeeks = 26
        private val totalDays = totalWeeks * 7L               // 182 days, 16 Nov 2026 -> 16 May 2027 inclusive
        private val startDT: LocalDateTime = startDate.atStartOfDay()
        private val endDT: LocalDateTime = startDT.plusDays(totalDays) // end of 16 May 2027

        // ---- Palette ----
        private val white = Color.parseColor("#F5F7FA")
        private val dim = Color.parseColor("#7C828A")
        private val grey = Color.parseColor("#26292D")
        private val green = Color.parseColor("#00E676")
        private val blue = Color.parseColor("#2EA8FF")

        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var w = 0
        private var h = 0

        private val tick = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) {
                    val delay = 1000L - (System.currentTimeMillis() % 1000L)
                    handler.postDelayed(this, delay)
                }
            }
        }

        // Set to true for 24-hour time
        private val USE_24H = false
        private val fmt12 = DateTimeFormatter.ofPattern("hh:mm:ss", Locale.ENGLISH)
        private val fmt24 = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ENGLISH)
        private val fmtAmPm = DateTimeFormatter.ofPattern("a", Locale.ENGLISH)
        private val fmtDate = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(tick)
            if (isVisible) handler.post(tick)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width; h = height
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            handler.removeCallbacks(tick)
        }

        // ---- Text helper ----
        private fun text(
            c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
            tf: Typeface, spacing: Float = 0f, glow: Float = 0f, glowColor: Int = color,
            align: Paint.Align = Paint.Align.CENTER
        ) {
            paint.reset()
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.typeface = tf
            paint.textSize = size
            paint.color = color
            paint.letterSpacing = spacing
            paint.textAlign = align
            if (glow > 0f) paint.setShadowLayer(glow, 0f, 0f, glowColor)
            c.drawText(s, x, y, paint)
        }

        private fun drawFrame() {
            if (w == 0 || h == 0) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                render(canvas)
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                }
            }
        }

        private fun render(c: Canvas) {
            val W = w.toFloat()
            val H = h.toFloat()
            c.drawColor(Color.BLACK)

            val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
            val medium = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            val thin = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            val mono = Typeface.create("monospace", Typeface.BOLD)

            // ---- Time math ----
            val now = LocalDateTime.now()
            val elapsedSec = max(0L, min(Duration.between(startDT, now).seconds, totalDays * 86400L))
            val fraction = elapsedSec.toDouble() / (totalDays * 86400.0)
            val percent = (fraction * 100).toInt()
            val elapsedDays = (elapsedSec / 86400L).toInt()
            val completedWeeks = min(elapsedDays / 7, totalWeeks)
            val remainingWeeks = totalWeeks - completedWeeks
            val finished = now.isAfter(endDT) || now.isEqual(endDT)
            val currentWeek = if (finished) 0 else min(elapsedDays / 7 + 1, totalWeeks)
            val notStarted = now.isBefore(startDT)

            val remSec = max(0L, Duration.between(now, endDT).seconds)
            val dd = remSec / 86400
            val hh = (remSec % 86400) / 3600
            val mm = (remSec % 3600) / 60
            val ss = remSec % 60
            val daysLeftCalendar = max(0L, ChronoUnit.DAYS.between(now.toLocalDate(), endDT.toLocalDate()))

            val cx = W / 2f

            // ---- Live clock + date (updates every second) ----
            val timeStr = now.format(if (USE_24H) fmt24 else fmt12)
            text(c, timeStr, cx, H * 0.135f, W * 0.13f, white, thin, 0.02f, glow = 22f, glowColor = white)
            if (!USE_24H) {
                val tw = paint.measureText(timeStr)
                text(c, now.format(fmtAmPm), cx + tw / 2f + W * 0.015f, H * 0.135f, W * 0.036f, blue, medium, 0.1f,
                    glow = 10f, align = Paint.Align.LEFT)
            }
            text(c, now.format(fmtDate).uppercase(Locale.ENGLISH), cx, H * 0.165f, W * 0.032f, dim, medium, 0.2f)

            // ---- Header (below the system clock zone, which is ~top 28%) ----
            text(c, "6 MONTHS CHALLENGE", cx, H * 0.262f, W * 0.032f, blue, medium, 0.35f, glow = 14f)
            text(c, "26 WEEKS OF DISCIPLINE", cx, H * 0.289f, W * 0.054f, white, light, 0.12f, glow = 22f, glowColor = white)
            text(c, "16 NOV 2026   —   16 MAY 2027", cx, H * 0.309f, W * 0.030f, dim, light, 0.18f)

            // ---- Progress ring ----
            val ringCy = H * 0.431f
            val radius = W * 0.16f
            val stroke = W * 0.024f
            rect.set(cx - radius, ringCy - radius, cx + radius, ringCy + radius)

            paint.reset(); paint.isAntiAlias = true
            paint.style = Paint.Style.STROKE; paint.strokeWidth = stroke
            paint.strokeCap = Paint.Cap.ROUND; paint.color = grey
            c.drawArc(rect, 0f, 360f, false, paint)

            val sweep = (fraction * 360.0).toFloat()
            if (sweep > 0.5f) {
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.STROKE; paint.strokeWidth = stroke
                paint.strokeCap = Paint.Cap.ROUND; paint.color = green
                paint.setShadowLayer(26f, 0f, 0f, green)
                c.drawArc(rect, -90f, sweep, false, paint)
            }

            text(c, "$percent%", cx, ringCy + W * 0.028f, W * 0.095f, white, thin, 0.02f, glow = 20f, glowColor = white)
            val weekLabel = when {
                finished -> "COMPLETE"
                notStarted -> "STARTS SOON"
                else -> "WEEK $currentWeek / $totalWeeks"
            }
            text(c, weekLabel, cx, ringCy + W * 0.085f, W * 0.027f, dim, medium, 0.2f)

            // ---- Stats row ----
            val statY = H * 0.560f
            val colW = W / 3f
            fun weeks(n: Int) = if (n == 1) "1 WEEK" else "$n WEEKS"
            val stats = listOf(
                Triple("COMPLETED", weeks(completedWeeks), green),
                Triple("REMAINING", weeks(remainingWeeks), white),
                Triple("TOTAL", "$totalWeeks WEEKS", blue)
            )
            stats.forEachIndexed { i, s ->
                val x = colW * i + colW / 2f
                text(c, s.first, x, statY, W * 0.024f, dim, medium, 0.22f)
                text(c, s.second, x, statY + W * 0.045f, W * 0.040f, s.third, light, 0.05f, glow = 12f)
            }

            // ---- Countdown ----
            val cdLabelY = H * 0.625f
            text(c, "$daysLeftCalendar DAYS UNTIL 16 MAY 2027", cx, cdLabelY, W * 0.028f, dim, medium, 0.18f)

            val boxes = listOf("DAYS" to dd, "HRS" to hh, "MIN" to mm, "SEC" to ss)
            val gap = W * 0.025f
            val boxW = (W * 0.84f - gap * 3) / 4f
            val boxH = W * 0.17f
            val boxTop = H * 0.640f
            val left0 = (W - (boxW * 4 + gap * 3)) / 2f
            boxes.forEachIndexed { i, b ->
                val l = left0 + i * (boxW + gap)
                rect.set(l, boxTop, l + boxW, boxTop + boxH)
                paint.reset(); paint.isAntiAlias = true
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
                paint.color = if (i == 3) blue else grey
                if (i == 3) paint.setShadowLayer(12f, 0f, 0f, blue)
                c.drawRoundRect(rect, W * 0.03f, W * 0.03f, paint)
                val v = if (i == 0) b.second.toString() else "%02d".format(b.second)
                text(c, v, l + boxW / 2f, boxTop + boxH * 0.60f, W * 0.066f, white, mono, 0f, glow = 14f, glowColor = white)
                text(c, b.first, l + boxW / 2f, boxTop + boxH * 0.88f, W * 0.021f, dim, medium, 0.2f)
            }

            // ---- Weekly grid: 26 indicators in 2 rows of 13 ----
            val cols = 13
            val gridTop = H * 0.758f
            val cell = W * 0.05f
            val cgap = (W * 0.88f - cell * cols) / (cols - 1)
            val gridLeft = (W - (cell * cols + cgap * (cols - 1))) / 2f
            val pulse = (0.55f + 0.45f * sin(System.currentTimeMillis() / 450.0)).toFloat()

            for (i in 0 until totalWeeks) {
                val weekNo = i + 1
                val row = i / cols
                val col = i % cols
                val l = gridLeft + col * (cell + cgap)
                val t = gridTop + row * (cell + cgap * 0.9f)
                rect.set(l, t, l + cell, t + cell)
                val r = cell * 0.28f

                paint.reset(); paint.isAntiAlias = true
                when {
                    weekNo <= completedWeeks -> {
                        paint.style = Paint.Style.FILL; paint.color = green
                        paint.setShadowLayer(10f, 0f, 0f, green)
                        c.drawRoundRect(rect, r, r, paint)
                    }
                    weekNo == currentWeek -> {
                        paint.style = Paint.Style.FILL; paint.color = grey
                        c.drawRoundRect(rect, r, r, paint)
                        paint.reset(); paint.isAntiAlias = true
                        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
                        paint.color = blue; paint.alpha = (120 + 135 * pulse).toInt()
                        paint.setShadowLayer(14f * pulse + 4f, 0f, 0f, blue)
                        c.drawRoundRect(rect, r, r, paint)
                    }
                    else -> {
                        paint.style = Paint.Style.FILL; paint.color = grey
                        c.drawRoundRect(rect, r, r, paint)
                    }
                }
            }

            // ---- Motivation (stays above the dock / app icon row) ----
            text(c, "NO EXCUSES. NO DISTRACTIONS.", cx, H * 0.850f, W * 0.036f, white, light, 0.16f, glow = 18f, glowColor = white)
            text(c, "JUST DISCIPLINE.", cx, H * 0.850f + W * 0.052f, W * 0.044f, green, medium, 0.30f, glow = 20f)
        }
    }
}
